package com.projects.InventoryMangementSystem.Controller;
import com.projects.InventoryMangementSystem.Entity.Product;
import com.projects.InventoryMangementSystem.Service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")

public class ProductController {
    @Autowired
    ProductService productService;

//    public ProductController(ProductService productService) {
//        this.productService = productService;
//    }

    // CREATE
    @PostMapping("/createProducts")
    public ResponseEntity<Product> createProduct(
            @RequestBody Product product) {

        Product savedProduct = productService.createProduct(product);

        return new ResponseEntity<>(
                savedProduct,
                HttpStatus.CREATED
        );
    }

    // GET ALL
    @GetMapping("/getProducts")
    public ResponseEntity<List<Product>> getAllProducts() {

        return ResponseEntity.ok(
                productService.getAllProducts()
        );
    }

    // GET BY ID
    @GetMapping("getProducts/{id}")
    public ResponseEntity<Product> getProductById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                productService.getProductById(id)
        );
    }

    // =========================
    // SEARCH (Google-style, works per field or globally)
    // =========================
    @GetMapping("/search")
    public ResponseEntity<List<Product>> searchProducts(
            @RequestParam(required = false) String q,
            @RequestParam(required = false) String id,
            @RequestParam(required = false) String productName,
            @RequestParam(required = false) String productType,
            @RequestParam(required = false) String brand,
            @RequestParam(required = false) String model,
            @RequestParam(required = false) String serialNumber,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String purchaseDate,
            @RequestParam(required = false) String price) {

        return ResponseEntity.ok(
                productService.searchProducts(
                        q, id, productName, productType, brand,
                        model, serialNumber, status, purchaseDate, price
                )
        );
    }

    // UPDATE
    @PutMapping("updateProducts/{id}")
    public ResponseEntity<Product> updateProduct(
            @PathVariable Long id,
            @RequestBody Product product) {

        return ResponseEntity.ok(
                productService.updateProduct(id, product)
        );
    }

    // DELETE
    @DeleteMapping("deleteProducts/{id}")
    public ResponseEntity<String> deleteProduct(
            @PathVariable Long id) {

        productService.deleteProduct(id);

        return ResponseEntity.ok(
                "Product deleted successfully"
        );
    }
}
