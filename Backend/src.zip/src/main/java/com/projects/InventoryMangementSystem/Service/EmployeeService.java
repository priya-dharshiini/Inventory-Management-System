package com.projects.InventoryMangementSystem.Service;


import com.projects.InventoryMangementSystem.Entity.Employee;
import com.projects.InventoryMangementSystem.Repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeService {
    @Autowired
   EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    // CREATE
    public Employee createEmployee(Employee employee) {

        if (employeeRepository.existsByEmail(employee.getEmail())) {
            throw new RuntimeException("Email already exists");
        }

        if (employee.getStatus() == null ||
                employee.getStatus().isBlank()) {

            employee.setStatus("ACTIVE");
        }

        return employeeRepository.save(employee);
    }

    // GET ALL
    public List<Employee> getAllEmployees() {

        return employeeRepository.findAll();
    }

    // GET BY ID
    public Employee getEmployeeById(Long id) {

        return employeeRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Employee not found with id: " + id
                        ));
    }

    // UPDATE
    public Employee updateEmployee(
            Long id,
            Employee updatedEmployee) {

        Employee existingEmployee =
                getEmployeeById(id);

        existingEmployee.setEmployeeName(
                updatedEmployee.getEmployeeName());

        existingEmployee.setEmail(
                updatedEmployee.getEmail());

        existingEmployee.setPhone(
                updatedEmployee.getPhone());

        existingEmployee.setDepartment(
                updatedEmployee.getDepartment());

        existingEmployee.setDesignation(
                updatedEmployee.getDesignation());

        existingEmployee.setStatus(
                updatedEmployee.getStatus());

        return employeeRepository.save(existingEmployee);
    }

    // DELETE
    public void deleteEmployee(Long id) {

        Employee employee =
                getEmployeeById(id);

        employeeRepository.delete(employee);
    }

    // =========================
    // SEARCH (Google-style, per-field + global)
    // =========================
    public List<Employee> searchEmployees(
            String q,
            String id,
            String employeeName,
            String email,
            String phone,
            String department,
            String designation,
            String status) {

        return employeeRepository.findAll().stream()
                .filter(e -> matches(e.getId() == null ? "" : String.valueOf(e.getId()), id))
                .filter(e -> matches(e.getEmployeeName(), employeeName))
                .filter(e -> matches(e.getEmail(), email))
                .filter(e -> matches(e.getPhone(), phone))
                .filter(e -> matches(e.getDepartment(), department))
                .filter(e -> matches(e.getDesignation(), designation))
                .filter(e -> matches(e.getStatus(), status))
                .filter(e -> matchesGlobal(q,
                        e.getId(), e.getEmployeeName(), e.getEmail(), e.getPhone(),
                        e.getDepartment(), e.getDesignation(), e.getStatus()))
                .collect(Collectors.toList());
    }

    private boolean matches(String fieldValue, String query) {

        if (query == null || query.isBlank()) {
            return true;
        }

        if (fieldValue == null) {
            return false;
        }

        return fieldValue.toLowerCase().contains(query.trim().toLowerCase());
    }

    private boolean matchesGlobal(String q, Object... fields) {

        if (q == null || q.isBlank()) {
            return true;
        }

        String needle = q.trim().toLowerCase();

        for (Object field : fields) {

            if (field != null && field.toString().toLowerCase().contains(needle)) {
                return true;
            }
        }

        return false;
    }
}
