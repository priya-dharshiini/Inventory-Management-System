package com.projects.InventoryMangementSystem.Repository;


import com.projects.InventoryMangementSystem.Entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository
        extends JpaRepository<Employee, Long> {

    long countByStatus(String status);
    boolean existsByEmail(String email);
}
