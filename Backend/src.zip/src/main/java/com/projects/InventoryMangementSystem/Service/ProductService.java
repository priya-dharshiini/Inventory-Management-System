package com.projects.InventoryMangementSystem.Service;


import com.projects.InventoryMangementSystem.Entity.Product;
import com.projects.InventoryMangementSystem.Repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {
     @Autowired
     ProductRepository productRepository;

//    public ProductService(ProductRepository productRepository) {
//        this.productRepository = productRepository;
//    }

    // CREATE
    public Product createProduct(Product product) {

        if (productRepository.existsBySerialNumber(product.getSerialNumber())) {
            throw new RuntimeException("Serial number already exists");
        }

        if (product.getStatus() == null || product.getStatus().isBlank()) {
            product.setStatus("AVAILABLE");
        }

        return productRepository.save(product);
    }

    // GET ALL
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    // GET BY ID
    public Product getProductById(Long id) {

        return productRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Product not found with id: " + id));
    }

    // UPDATE
    public Product updateProduct(Long id, Product updatedProduct) {

        Product existingProduct = getProductById(id);

        existingProduct.setProductName(updatedProduct.getProductName());
        existingProduct.setProductType(updatedProduct.getProductType());
        existingProduct.setBrand(updatedProduct.getBrand());
        existingProduct.setModel(updatedProduct.getModel());
        existingProduct.setPurchaseDate(updatedProduct.getPurchaseDate());
        existingProduct.setPrice(updatedProduct.getPrice());
        existingProduct.setStatus(updatedProduct.getStatus());

        return productRepository.save(existingProduct);
    }

    // DELETE
    public void deleteProduct(Long id) {

        Product product = getProductById(id);

        productRepository.delete(product);
    }

    // =========================
    // SEARCH (Google-style, per-field + global)
    // =========================
    public List<Product> searchProducts(
            String q,
            String id,
            String productName,
            String productType,
            String brand,
            String model,
            String serialNumber,
            String status,
            String purchaseDate,
            String price) {

        return productRepository.findAll().stream()
                .filter(p -> matches(p.getId() == null ? "" : String.valueOf(p.getId()), id))
                .filter(p -> matches(p.getProductName(), productName))
                .filter(p -> matches(p.getProductType(), productType))
                .filter(p -> matches(p.getBrand(), brand))
                .filter(p -> matches(p.getModel(), model))
                .filter(p -> matches(p.getSerialNumber(), serialNumber))
                .filter(p -> matches(p.getStatus(), status))
                .filter(p -> matches(p.getPurchaseDate() == null ? "" : p.getPurchaseDate().toString(), purchaseDate))
                .filter(p -> matches(p.getPrice() == null ? "" : String.valueOf(p.getPrice()), price))
                .filter(p -> matchesGlobal(q,
                        p.getId(), p.getProductName(), p.getProductType(), p.getBrand(),
                        p.getModel(), p.getSerialNumber(), p.getStatus(),
                        p.getPurchaseDate(), p.getPrice()))
                .collect(Collectors.toList());
    }

    private boolean matches(String fieldValue, String query) {

        if (query == null || query.isBlank()) {
            return true;
        }

        if (fieldValue == null) {
            return false;
        }

        return fieldValue.toLowerCase().contains(query.trim().toLowerCase());
    }

    private boolean matchesGlobal(String q, Object... fields) {

        if (q == null || q.isBlank()) {
            return true;
        }

        String needle = q.trim().toLowerCase();

        for (Object field : fields) {

            if (field != null && field.toString().toLowerCase().contains(needle)) {
                return true;
            }
        }

        return false;
    }
}
