package com.projects.InventoryMangementSystem.Controller;

import com.projects.InventoryMangementSystem.Entity.MasterValue;
import com.projects.InventoryMangementSystem.Service.MasterValueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Generic REST API for all master modules:
 * Department, Designation, Role, Status.
 *
 * Example usage:
 *   GET    /api/masters/DEPARTMENT
 *   POST   /api/masters/DEPARTMENT          { "value": "IT" }
 *   PUT    /api/masters/DEPARTMENT/5        { "value": "IT Support" }
 *   DELETE /api/masters/DEPARTMENT/5
 */
@RestController
@RequestMapping("/api/masters")
public class MasterValueController {

    @Autowired
    MasterValueService masterValueService;

    // CREATE
    @PostMapping("/{type}")
    public ResponseEntity<MasterValue> createValue(
            @PathVariable String type,
            @RequestBody MasterValue masterValue) {

        MasterValue saved = masterValueService.createValue(type, masterValue);

        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }

    // GET ALL BY TYPE
    @GetMapping("/{type}")
    public ResponseEntity<List<MasterValue>> getByType(
            @PathVariable String type) {

        return ResponseEntity.ok(masterValueService.getByType(type));
    }

    // GET BY ID
    @GetMapping("/entry/{id}")
    public ResponseEntity<MasterValue> getById(@PathVariable Long id) {

        return ResponseEntity.ok(masterValueService.getById(id));
    }

    // UPDATE
    @PutMapping("/{type}/{id}")
    public ResponseEntity<MasterValue> updateValue(
            @PathVariable String type,
            @PathVariable Long id,
            @RequestBody MasterValue masterValue) {

        return ResponseEntity.ok(masterValueService.updateValue(id, masterValue));
    }

    // DELETE
    @DeleteMapping("/{type}/{id}")
    public ResponseEntity<String> deleteValue(
            @PathVariable String type,
            @PathVariable Long id) {

        masterValueService.deleteValue(id);

        return ResponseEntity.ok("Master value deleted successfully");
    }
}
