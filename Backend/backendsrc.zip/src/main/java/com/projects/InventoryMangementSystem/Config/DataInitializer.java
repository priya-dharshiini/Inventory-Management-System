package com.projects.InventoryMangementSystem.Config;

import com.projects.InventoryMangementSystem.Entity.MasterValue;
import com.projects.InventoryMangementSystem.Entity.User;
import com.projects.InventoryMangementSystem.Repository.MasterValueRepository;
import com.projects.InventoryMangementSystem.Repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class DataInitializer implements CommandLineRunner {


    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_PASSWORD = "admin123";
    private static final String ADMIN_ROLE = "ADMIN";

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final MasterValueRepository masterValueRepository;

    public DataInitializer(
            UserRepository userRepository,
            PasswordEncoder passwordEncoder,
            MasterValueRepository masterValueRepository) {

        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.masterValueRepository = masterValueRepository;
    }

    @Override
    public void run(String... args) {

        if (userRepository.findByUsername(ADMIN_USERNAME).isEmpty()) {

            User admin = new User();
            admin.setUsername(ADMIN_USERNAME);
            admin.setPassword(passwordEncoder.encode(ADMIN_PASSWORD));
            admin.setRole(ADMIN_ROLE);

            userRepository.save(admin);

            System.out.println(
                    "Seeded default admin user into DB: " + ADMIN_USERNAME
            );
        }

        seedMasterData();
    }

    private void seedMasterData() {

        Map<String, List<String>> defaults = Map.of(
                "DEPARTMENT", List.of("IT", "HR", "Finance", "Development"),
                "DESIGNATION", List.of("Manager", "Team Lead", "Developer", "Analyst", "Intern"),
                "ROLE", List.of("Admin", "Manager", "Employee", "Viewer"),
                "STATUS", List.of("ACTIVE", "INACTIVE", "AVAILABLE", "ASSIGNED", "MAINTENANCE", "DAMAGED", "RETURNED")
        );

        for (Map.Entry<String, List<String>> entry : defaults.entrySet()) {

            String type = entry.getKey();

            if (!masterValueRepository.findByTypeIgnoreCaseOrderByValueAsc(type).isEmpty()) {
                continue;
            }

            for (String value : entry.getValue()) {

                MasterValue masterValue = new MasterValue();
                masterValue.setType(type);
                masterValue.setValue(value);
                masterValue.setActive(true);

                masterValueRepository.save(masterValue);
            }

            System.out.println("Seeded default " + type + " master values");
        }
    }
}
