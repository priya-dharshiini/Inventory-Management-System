package com.projects.InventoryMangementSystem.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Generic master-data entity used to back the
 * Department / Designation / Role / Status masters.
 *
 * The "type" column distinguishes which master a row
 * belongs to (DEPARTMENT, DESIGNATION, ROLE, STATUS).
 */
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(
        name = "master_values",
        uniqueConstraints = @UniqueConstraint(
                columnNames = {"type", "value"}
        )
)
public class MasterValue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // DEPARTMENT | DESIGNATION | ROLE | STATUS
    @Column(nullable = false)
    private String type;

    @Column(nullable = false)
    private String value;

    // Optional free-text description for the master entry
    private String description;

    // Allows soft-disabling a value without deleting it
    private Boolean active = true;
}
