package com.projects.InventoryMangementSystem.Service;

import com.projects.InventoryMangementSystem.Entity.AssetAssignment;
import com.projects.InventoryMangementSystem.Entity.Employee;
import com.projects.InventoryMangementSystem.Entity.Product;
import com.projects.InventoryMangementSystem.Repository.AssetAssignmentRepository;
import com.projects.InventoryMangementSystem.Repository.EmployeeRepository;
import com.projects.InventoryMangementSystem.Repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class AssetAssignmentService {

    private final AssetAssignmentRepository assignmentRepository;
    private final EmployeeRepository employeeRepository;
    private final ProductRepository productRepository;

    public AssetAssignmentService(
            AssetAssignmentRepository assignmentRepository,
            EmployeeRepository employeeRepository,
            ProductRepository productRepository) {

        this.assignmentRepository = assignmentRepository;
        this.employeeRepository = employeeRepository;
        this.productRepository = productRepository;
    }


    // =========================
    // CREATE ASSIGNMENT
    // =========================
    public AssetAssignment createAssignment(
            Long employeeId,
            Long productId,
            String assignmentType,
            LocalDate fromDate,
            LocalDate toDate,
            String remarks) {

        // 1. Find Employee
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() ->
                        new RuntimeException("Employee not found with id: " + employeeId)
                );


        // 2. Find Product
        Product product = productRepository.findById(productId)
                .orElseThrow(() ->
                        new RuntimeException("Product not found with id: " + productId)
                );


        // 3. Check Product Status
        String productStatus = product.getStatus();

        System.out.println("Product ID: " + product.getId());
        System.out.println("Product Status: [" + productStatus + "]");


        if (productStatus == null ||
                !"AVAILABLE".equalsIgnoreCase(productStatus.trim())) {

            throw new RuntimeException(
                    "Product is not available. Current status: "
                            + productStatus
            );
        }


        // 4. Validate Assignment Type
        if (assignmentType == null ||
                assignmentType.isBlank()) {

            throw new RuntimeException(
                    "Assignment type is required"
            );
        }


        // 5. TEMPORARY Assignment Validation
        if ("TEMPORARY".equalsIgnoreCase(assignmentType)) {

            if (fromDate == null || toDate == null) {

                throw new RuntimeException(
                        "Temporary assignment requires From Date and To Date"
                );
            }

            if (!toDate.isAfter(fromDate)) {

                throw new RuntimeException(
                        "To Date must be greater than From Date"
                );
            }
        }


        // 6. PERMANENT Assignment Validation
        else if ("PERMANENT".equalsIgnoreCase(assignmentType)) {

            if (fromDate == null) {

                throw new RuntimeException(
                        "Permanent assignment requires From Date"
                );
            }

            // Permanent assignment-ku To Date thevai illa
            toDate = null;
        }


        // 7. Invalid Assignment Type
        else {

            throw new RuntimeException(
                    "Assignment type must be TEMPORARY or PERMANENT"
            );
        }


        // 8. Create Assignment Object
        AssetAssignment assignment = new AssetAssignment();

        assignment.setEmployee(employee);
        assignment.setProduct(product);

        assignment.setAssignmentType(
                assignmentType.toUpperCase()
        );

        assignment.setFromDate(fromDate);
        assignment.setToDate(toDate);

        assignment.setStatus("ACTIVE");

        assignment.setRemarks(remarks);


        // 9. Change Product Status
        // AVAILABLE → ASSIGNED
        product.setStatus("ASSIGNED");

        productRepository.save(product);


        // 10. Save Assignment
        return assignmentRepository.save(assignment);
    }


    // =========================
    // GET ALL ASSIGNMENTS
    // =========================
    public List<AssetAssignment> getAllAssignments() {

        return assignmentRepository.findAll();
    }


    // =========================
    // GET ASSIGNMENT BY ID
    // =========================
    public AssetAssignment getAssignmentById(Long id) {

        return assignmentRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Assignment not found with id: " + id
                        )
                );
    }


    // =========================
    // RETURN ASSET
    // =========================
    public AssetAssignment returnAsset(
            Long id,
            String condition,
            String remarks) {

        // 1. Find Assignment
        AssetAssignment assignment =
                getAssignmentById(id);


        // 2. Check Assignment Status
        if (!"ACTIVE".equalsIgnoreCase(
                assignment.getStatus())) {

            throw new RuntimeException(
                    "Asset is already returned"
            );
        }


        // 3. Update Assignment
        assignment.setStatus("RETURNED");

        assignment.setReturnedDate(
                LocalDate.now()
        );

        assignment.setCondition(condition);

        assignment.setRemarks(remarks);


        // 4. Get Product
        Product product =
                assignment.getProduct();


        // 5. Change Product Status
        // ASSIGNED → AVAILABLE
        product.setStatus("AVAILABLE");

        productRepository.save(product);


        // 6. Save Assignment
        return assignmentRepository.save(assignment);
    }


    // =========================
    // GET BY STATUS
    // =========================
    public List<AssetAssignment> getByStatus(
            String status) {

        return assignmentRepository.findByStatus(status);
    }


    // =========================
    // GET BY ASSIGNMENT TYPE
    // =========================
    public List<AssetAssignment> getByAssignmentType(
            String assignmentType) {

        return assignmentRepository
                .findByAssignmentType(assignmentType);
    }
}