package com.projects.InventoryMangementSystem.Service;


import com.projects.InventoryMangementSystem.Entity.Employee;
import com.projects.InventoryMangementSystem.Repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {
    @Autowired
   EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    // CREATE
    public Employee createEmployee(Employee employee) {

        if (employeeRepository.existsByEmail(employee.getEmail())) {
            throw new RuntimeException("Email already exists");
        }

        if (employee.getStatus() == null ||
                employee.getStatus().isBlank()) {

            employee.setStatus("ACTIVE");
        }

        return employeeRepository.save(employee);
    }

    // GET ALL
    public List<Employee> getAllEmployees() {

        return employeeRepository.findAll();
    }

    // GET BY ID
    public Employee getEmployeeById(Long id) {

        return employeeRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Employee not found with id: " + id
                        ));
    }

    // UPDATE
    public Employee updateEmployee(
            Long id,
            Employee updatedEmployee) {

        Employee existingEmployee =
                getEmployeeById(id);

        existingEmployee.setEmployeeName(
                updatedEmployee.getEmployeeName());

        existingEmployee.setEmail(
                updatedEmployee.getEmail());

        existingEmployee.setPhone(
                updatedEmployee.getPhone());

        existingEmployee.setDepartment(
                updatedEmployee.getDepartment());

        existingEmployee.setDesignation(
                updatedEmployee.getDesignation());

        existingEmployee.setStatus(
                updatedEmployee.getStatus());

        return employeeRepository.save(existingEmployee);
    }

    // DELETE
    public void deleteEmployee(Long id) {

        Employee employee =
                getEmployeeById(id);

        employeeRepository.delete(employee);
    }
}
