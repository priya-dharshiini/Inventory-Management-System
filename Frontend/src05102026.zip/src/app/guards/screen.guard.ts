import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

import { AuthService } from '../services/auth';

// Blocks opening a screen by URL if the user's role has no "View" access to it.
export const screenGuard = (screen: string): CanActivateFn => () => {

  const authService = inject(AuthService);
  const router = inject(Router);

  if (authService.canView(screen)) {
    return true;
  }

  router.navigate(['/home']);
  return false;
};
