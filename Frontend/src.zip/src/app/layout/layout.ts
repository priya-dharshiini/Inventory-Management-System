import { Component } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-layout',
  imports: [
    RouterLink,
    RouterOutlet
  ],
  templateUrl: './layout.html',
  styleUrl: './layout.css'
})
export class Layout {

  constructor(private router: Router) {}

  logout(): void {

    const confirmLogout = confirm(
      'Are you sure you want to logout?'
    );

    if (confirmLogout) {

      // Remove JWT token
      localStorage.removeItem('token');

      // Go to login page
      this.router.navigate(['/login']);
    }
  }
}