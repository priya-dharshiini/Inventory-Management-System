import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import { ActivatedRoute, Router } from '@angular/router';

import { EmployeeService } from '../services/employee';


@Component({
  selector: 'app-employee-form',

  imports: [
    ReactiveFormsModule
  ],

  templateUrl: './employee-form.html',

  styleUrl: './employee-form.css'
})
export class EmployeeForm implements OnInit {

  // ==============================
  // FORM
  // ==============================

  employeeForm!: FormGroup;


  // ==============================
  // EMPLOYEE ID
  // ==============================

  employeeId: number | null = null;


  // ==============================
  // ADD / EDIT MODE
  // ==============================

  isEditMode: boolean = false;


  constructor(
    private fb: FormBuilder,

    private employeeService: EmployeeService,

    private route: ActivatedRoute,

    private router: Router
  ) {}


  // ==============================
  // INITIALIZE
  // ==============================

  ngOnInit(): void {

    // Create empty form

    this.employeeForm = this.fb.group({

      employeeName: [
        '',
        Validators.required
      ],

      employeeCode: [
        '',
        Validators.required
      ],

      email: [
        '',
        [
          Validators.required,
          Validators.email
        ]
      ],

      phone: [
        '',
        Validators.required
      ],

      department: [
        '',
        Validators.required
      ],

      designation: [
        '',
        Validators.required
      ],

      joiningDate: [
        '',
        Validators.required
      ],

      status: [
        'ACTIVE',
        Validators.required
      ]

    });


    // ==========================================
    // CHECK URL FOR ID
    // ==========================================

    const id =
      this.route.snapshot.paramMap.get('id');


    // ==========================================
    // EDIT MODE
    // ==========================================

    if (id) {

      console.log(
        'Edit Employee ID:',
        id
      );


      this.employeeId =
        Number(id);


      this.isEditMode = true;


      // Fetch ONLY in edit mode

      this.getEmployeeById(
        this.employeeId
      );

    }


    // ==========================================
    // ADD MODE
    // ==========================================

    else {

      console.log(
        'Add Employee Mode'
      );


      this.isEditMode = false;

      this.employeeId = null;

      // No API call
      // Empty form

    }

  }


  // ==========================================
  // GET EMPLOYEE BY ID
  // ==========================================

  getEmployeeById(id: number): void {

    console.log(
      'Fetching employee ID:',
      id
    );


    this.employeeService
      .getEmployeeById(id)
      .subscribe({

        next: (employee) => {

          console.log(
            'Selected Employee:',
            employee
          );


          // Fill form with existing data

          this.employeeForm.patchValue({

            employeeName:
              employee.employeeName,

            employeeCode:
              employee.employeeCode,

            email:
              employee.email,

            phone:
              employee.phone,

            department:
              employee.department,

            designation:
              employee.designation,

            joiningDate:
              employee.joiningDate,

            status:
              employee.status

          });

        },


        error: (error) => {

          console.error(
            'Error loading employee:',
            error
          );


          alert(
            'Failed to load employee'
          );

        }

      });

  }


  // ==========================================
  // ADD / UPDATE
  // ==========================================

  submitEmployee(): void {


    // ========================================
    // VALIDATE
    // ========================================

    if (this.employeeForm.invalid) {

      this.employeeForm.markAllAsTouched();

      return;

    }


    // Get form data

    const employeeData =
      this.employeeForm.value;


    console.log(
      'Employee Form Data:',
      employeeData
    );


    // ========================================
    // EDIT / UPDATE
    // ========================================

    if (
      this.isEditMode &&
      this.employeeId !== null
    ) {

      console.log(
        'Updating Employee ID:',
        this.employeeId
      );


      this.employeeService
        .updateEmployee(
          this.employeeId,
          employeeData
        )
        .subscribe({

          next: (response) => {

            console.log(
              'Employee updated successfully:',
              response
            );


            alert(
              'Employee updated successfully'
            );


            this.router.navigate([
              '/employees'
            ]);

          },


          error: (error) => {

            console.error(
              'Update employee error:',
              error
            );


            alert(
              'Failed to update employee'
            );

          }

        });


      return;

    }


    // ========================================
    // ADD / CREATE
    // ========================================

    console.log(
      'Adding new employee'
    );


    this.employeeService
      .addEmployee(employeeData)
      .subscribe({

        next: (response) => {

          console.log(
            'Employee created successfully:',
            response
          );


          alert(
            'Employee added successfully'
          );


          this.router.navigate([
            '/employees'
          ]);

        },


        error: (error) => {

          console.error(
            'Add employee error:',
            error
          );


          alert(
            'Failed to add employee'
          );

        }

      });

  }


  // ==========================================
  // CANCEL
  // ==========================================

  cancel(): void {

    this.router.navigate([
      '/employees'
    ]);

  }

}