import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import { ActivatedRoute, Router } from '@angular/router';

import { ProductService } from '../services/product';


@Component({
  selector: 'app-product-form',

  imports: [
    ReactiveFormsModule
  ],

  templateUrl: './product-form.html',

  styleUrl: './product-form.css'
})
export class ProductForm implements OnInit {

  // ==============================
  // FORM
  // ==============================

  productForm!: FormGroup;


  // ==============================
  // EDIT PRODUCT ID
  // ==============================

  productId: number | null = null;


  // ==============================
  // ADD / EDIT MODE
  // ==============================

  isEditMode: boolean = false;


  constructor(
    private fb: FormBuilder,

    private productService: ProductService,

    private route: ActivatedRoute,

    private router: Router
  ) {}


  // ==============================
  // INITIALIZE
  // ==============================

  ngOnInit(): void {

    // Create empty form
    this.productForm = this.fb.group({

      productName: [
        '',
        Validators.required
      ],

      productType: [
        '',
        Validators.required
      ],

      brand: [
        '',
        Validators.required
      ],

      model: [
        '',
        Validators.required
      ],

      serialNumber: [
        '',
        Validators.required
      ],

      purchaseDate: [
        '',
        Validators.required
      ],

      price: [
        '',
        [
          Validators.required,
          Validators.min(0)
        ]
      ],

      status: [
        'AVAILABLE',
        Validators.required
      ]

    });


    // ==========================================
    // CHECK URL FOR PRODUCT ID
    // ==========================================

    const id = this.route.snapshot.paramMap.get('id');


    // ==========================================
    // EDIT MODE
    // ==========================================

    if (id) {

      console.log('Edit Product ID:', id);

      this.productId = Number(id);

      this.isEditMode = true;

      // Product fetch ONLY in edit mode
      this.getProductById(this.productId);

    }


    // ==========================================
    // ADD MODE
    // ==========================================

    else {

      console.log('Add Product Mode');

      this.isEditMode = false;

      this.productId = null;

      // No API call here
      // Form remains empty

    }

  }


  // ==========================================
  // GET PRODUCT BY ID
  // ==========================================

  getProductById(id: number): void {

    console.log(
      'Fetching product with ID:',
      id
    );


    this.productService
      .getProductById(id)
      .subscribe({

        next: (product) => {

          console.log(
            'Selected Product:',
            product
          );


          // ==================================
          // FILL FORM WITH PRODUCT DATA
          // ==================================

          this.productForm.patchValue({

            productName:
              product.productName,

            productType:
              product.productType,

            brand:
              product.brand,

            model:
              product.model,

            serialNumber:
              product.serialNumber,

            purchaseDate:
              product.purchaseDate,

            price:
              product.price,

            status:
              product.status

          });

        },


        error: (error) => {

          console.error(
            'Error loading product:',
            error
          );

          alert(
            'Failed to load product'
          );

        }

      });

  }


  // ==========================================
  // ADD / UPDATE PRODUCT
  // ==========================================

  submitProduct(): void {


    // ========================================
    // VALIDATE FORM
    // ========================================

    if (this.productForm.invalid) {

      this.productForm.markAllAsTouched();

      return;

    }


    // Get form data

    const productData =
      this.productForm.value;


    console.log(
      'Form Data:',
      productData
    );


    // ========================================
    // EDIT / UPDATE
    // ========================================

    if (
      this.isEditMode &&
      this.productId !== null
    ) {

      console.log(
        'Updating Product ID:',
        this.productId
      );


      this.productService
        .updateProduct(
          this.productId,
          productData
        )
        .subscribe({

          next: (response) => {

            console.log(
              'Product updated successfully:',
              response
            );


            alert(
              'Product updated successfully'
            );


            // Go back to product list

            this.router.navigate([
              '/products'
            ]);

          },


          error: (error) => {

            console.error(
              'Update error:',
              error
            );


            alert(
              'Failed to update product'
            );

          }

        });


      return;

    }


    // ========================================
    // ADD / CREATE
    // ========================================

    console.log(
      'Adding new product'
    );


    this.productService
      .addProduct(productData)
      .subscribe({

        next: (response) => {

          console.log(
            'Product created successfully:',
            response
          );


          alert(
            'Product added successfully'
          );


          // Go back to product list

          this.router.navigate([
            '/products'
          ]);

        },


        error: (error) => {

          console.error(
            'Create product error:',
            error
          );


          alert(
            'Failed to add product'
          );

        }

      });

  }


  // ==========================================
  // CANCEL
  // ==========================================

  cancel(): void {

    this.router.navigate([
      '/products'
    ]);

  }

}