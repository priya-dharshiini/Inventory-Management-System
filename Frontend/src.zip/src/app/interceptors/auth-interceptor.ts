import { HttpInterceptorFn } from '@angular/common/http';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { inject } from '@angular/core';

export const authInterceptor: HttpInterceptorFn = (req, next) => {

  const router = inject(Router);

  // Login/Register API-ku token add panna vendam
  if (req.url.includes('/api/auth/')) {
    return next(req);
  }

  const token = localStorage.getItem('token');

  if (token) {

    const authReq = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });

    return next(authReq).pipe(

      catchError((error) => {

        if (error.status === 401 || error.status === 403) {

          console.log('Token expired or invalid');

          // Old token remove
          localStorage.removeItem('token');

          // Login page-ku redirect
          router.navigate(['/login']);
        }

        return throwError(() => error);
      })

    );
  }

  // Token illana login page
  router.navigate(['/login']);

  return throwError(() => new Error('No authentication token'));
};