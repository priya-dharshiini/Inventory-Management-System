import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private apiUrl = 'http://localhost:8080/api/products';

  constructor(private http: HttpClient) {}

  // Get all products
  getAllProducts(): Observable<any[]> {
    return this.http.get<any[]>(
      `${this.apiUrl}/getProducts`
    );
  }

  // Get product by ID
  getProductById(id: number): Observable<any> {
    return this.http.get<any>(
      `${this.apiUrl}/getProducts/${id}`
    );
  }

  // Add product
  createProduct(product: any): Observable<any> {
    return this.http.post<any>(
      `${this.apiUrl}/createProducts`,
      product
    );
  }

  // Update product
  updateProduct(
    id: number,
    product: any
  ): Observable<any> {

    return this.http.put<any>(
      `${this.apiUrl}/updateProducts/${id}`,
      product
    );
  }

  // Delete product
  deleteProduct(id: number): Observable<any> {

    return this.http.delete<any>(
      `${this.apiUrl}/deleteProducts/${id}`
    );
  }

  addProduct(product: any): Observable<any> {
    // Delegates to the real create endpoint (kept for backward compatibility)
    return this.createProduct(product);
  }

  // =========================
  // SEARCH (Google-style, per-field or global)
  // =========================
  searchProducts(criteria: { [key: string]: any }): Observable<any[]> {

    let params = new HttpParams();

    Object.keys(criteria).forEach((key) => {
      const value = criteria[key];

      if (value !== null && value !== undefined && String(value).trim() !== '') {
        params = params.set(key, String(value).trim());
      }
    });

    return this.http.get<any[]>(`${this.apiUrl}/search`, { params });
  }
}