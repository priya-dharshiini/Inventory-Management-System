import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private apiUrl = 'http://localhost:8080/api/employees';

  constructor(private http: HttpClient) {}

  getAllEmployees(): Observable<any[]> {
    return this.http.get<any[]>(
      `${this.apiUrl}/getEmployees`
    );
  }

  createEmployee(employee: any): Observable<any> {
    return this.http.post<any>(
      `${this.apiUrl}/createEmployees`,
      employee
    );
  }

  getEmployeeById(id: number): Observable<any> {
    return this.http.get<any>(
      `${this.apiUrl}/getEmployees/${id}`
    );
  }

  updateEmployee(
    id: number,
    employee: any
  ): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}/updateEmployees/${id}`,
      employee
    );
  }

  deleteEmployee(id: number): Observable<any> {
    return this.http.delete<any>(
      `${this.apiUrl}/deleteById/${id}`
    );
  }

  addEmployee(employee: any): Observable<any> {
    // Delegates to the real create endpoint (kept for backward compatibility;
    // the original implementation posted to a non-existent path)
    return this.createEmployee(employee);
  }

  // =========================
  // SEARCH (Google-style, per-field or global)
  // =========================
  searchEmployees(criteria: { [key: string]: any }): Observable<any[]> {

    let params = new HttpParams();

    Object.keys(criteria).forEach((key) => {
      const value = criteria[key];

      if (value !== null && value !== undefined && String(value).trim() !== '') {
        params = params.set(key, String(value).trim());
      }
    });

    return this.http.get<any[]>(`${this.apiUrl}/search`, { params });
  }

}