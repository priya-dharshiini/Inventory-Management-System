import { Routes } from '@angular/router';

import { Login } from './login/login';

import { Layout } from './layout/layout';
import { Home } from './home/home';

import { ProductManagement } from './product-management/product-management';
import { ProductForm } from './product-form/product-form';

import { EmployeeManagement } from './employee-management/employee-management';
import { EmployeeForm } from './employee-form/employee-form';

import { AssetAssignment } from './asset-assignment/asset-assignment';
import { AssignmentRegister } from './assignment-register/assignment-register';
import { MasterManagement } from './master-management/master-management';

export const routes: Routes = [

  // =========================
  // FIRST PAGE
  // =========================

  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },

  // =========================
  // LOGIN
  // =========================

  {
    path: 'login',
    component: Login
  },

  // =========================
  // APPLICATION
  // =========================

  {
    path: '',
    component: Layout,

    children: [

      {
        path: 'home',
        component: Home
      },

      {
        path: 'products',
        component: ProductManagement
      },

      {
        path: 'products/add',
        component: ProductForm
      },

      {
        path: 'products/edit/:id',
        component: ProductForm
      },

      {
        path: 'employees',
        component: EmployeeManagement
      },

      {
        path: 'employees/add',
        component: EmployeeForm
      },

      {
        path: 'employees/edit/:id',
        component: EmployeeForm
      },

      {
        path: 'asset-assignment',
        component: AssetAssignment
      },

      {
        path: 'assignment-register',
        component: AssignmentRegister
      },

      {
        path: 'masters',
        component: MasterManagement
      }

    ]
  },

  // =========================
  // INVALID URL
  // =========================

  {
    path: '**',
    redirectTo: 'login'
  }

];