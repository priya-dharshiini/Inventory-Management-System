import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { AuthService } from '../services/auth';

@Component({
  selector: 'app-login',
  imports: [
    FormsModule
  ],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {

  username: string = '';
  password: string = '';

  errorMessage: string = '';
  loading: boolean = false;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  login(): void {

    // Clear previous error
    this.errorMessage = '';

    // Check username
    if (!this.username.trim()) {
      this.errorMessage = 'Please enter username';
      return;
    }

    // Check password
    if (!this.password.trim()) {
      this.errorMessage = 'Please enter password';
      return;
    }

    this.loading = true;

    this.authService
      .login(this.username, this.password)
      .subscribe({

        next: (response) => {

          console.log('Login successful');
          console.log('JWT Token:', response);

          // Save JWT token
          localStorage.setItem('token', response);

          this.loading = false;

          // Go to Home page
          this.router.navigate(['/home']);
        },

        error: (error) => {

          console.error('Login failed:', error);

          this.loading = false;

          this.errorMessage =
            error.error?.message ||
            error.error ||
            'Invalid username or password';
        }

      });
  }

}