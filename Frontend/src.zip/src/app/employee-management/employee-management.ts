import {
  Component,
  OnInit,
  ChangeDetectorRef
} from '@angular/core';

import { Router } from '@angular/router';

import { EmployeeService } from '../services/employee';
import { MasterService } from '../services/master';

import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-employee-management',

  imports: [
    FormsModule
  ],

  templateUrl: './employee-management.html',

  styleUrl: './employee-management.css'
})
export class EmployeeManagement implements OnInit {


  // ==============================
  // EMPLOYEE LIST
  // ==============================

  employees: any[] = [];


  // ==============================
  // MASTER DATA (for dropdowns)
  // ==============================

  departmentOptions: any[] = [];
  designationOptions: any[] = [];
  statusOptions: any[] = [];


  // ==============================
  // GOOGLE-STYLE PER-COLUMN SEARCH
  // ==============================

  searchFields: any = {
    id: '',
    employeeName: '',
    email: '',
    phone: '',
    department: '',
    designation: '',
    status: ''
  };

  private searchDebounce: any = null;


  // ==============================
  // INLINE ADD
  // ==============================

  isAddingNew: boolean = false;

  newRow: any = this.emptyEmployee();


  // ==============================
  // INLINE EDIT
  // ==============================

  editingId: number | null = null;

  editRow: any = {};


  constructor(

    private employeeService: EmployeeService,

    private masterService: MasterService,

    private router: Router,

    private cdr: ChangeDetectorRef

  ) {}


  // ==============================
  // INITIALIZE
  // ==============================

  ngOnInit(): void {

    this.getEmployees();
    this.loadMasterOptions();

  }


  emptyEmployee(): any {
    return {
      employeeName: '',
      email: '',
      phone: '',
      department: '',
      designation: '',
      status: 'ACTIVE'
    };
  }


  // ==============================
  // LOAD MASTER OPTIONS (Department / Designation / Status)
  // ==============================

  loadMasterOptions(): void {

    this.masterService.getByType('DEPARTMENT').subscribe({
      next: (data) => { this.departmentOptions = data || []; },
      error: (error) => console.error('Error loading department master:', error)
    });

    this.masterService.getByType('DESIGNATION').subscribe({
      next: (data) => { this.designationOptions = data || []; },
      error: (error) => console.error('Error loading designation master:', error)
    });

    // Employee Status is fetched from the EMPLOYEE_STATUS master only —
    // never mixed with Product Status values.
    this.masterService.getByType('EMPLOYEE_STATUS').subscribe({
      next: (data) => { this.statusOptions = data || []; },
      error: (error) => console.error('Error loading status master:', error)
    });

  }


  // ==============================
  // GET ALL EMPLOYEES
  // ==============================

  getEmployees(): void {

    this.employeeService
      .getAllEmployees()
      .subscribe({

        next: (data) => {

          this.employees = [...data];

          this.cdr.detectChanges();

        },


        error: (error) => {

          console.error(
            'Error loading employees:',
            error
          );


          alert(
            'Failed to load employees'
          );

        }

      });

  }


  // ==============================
  // GOOGLE-STYLE LIVE SEARCH (per field/column)
  // ==============================

  onSearchInput(): void {

    if (this.searchDebounce) {
      clearTimeout(this.searchDebounce);
    }

    this.searchDebounce = setTimeout(() => {
      this.runSearch();
    }, 300);

  }

  runSearch(): void {

    const hasCriteria = Object.values(this.searchFields)
      .some((v: any) => v !== null && v !== undefined && String(v).trim() !== '');

    if (!hasCriteria) {
      this.getEmployees();
      return;
    }

    this.employeeService
      .searchEmployees(this.searchFields)
      .subscribe({

        next: (data) => {

          this.employees = [...data];

          this.cdr.detectChanges();

        },

        error: (error) => {

          console.error('Search error:', error);

          this.employees = [];

          this.cdr.detectChanges();

        }

      });

  }

  clearSearch(): void {

    this.searchFields = {
      id: '',
      employeeName: '',
      email: '',
      phone: '',
      department: '',
      designation: '',
      status: ''
    };

    this.getEmployees();

  }


  // ==============================
  // INLINE ADD EMPLOYEE
  // ==============================

  addEmployee(): void {

    this.isAddingNew = true;
    this.newRow = this.emptyEmployee();

  }

  saveNewEmployee(): void {

    if (!this.newRow.employeeName || !this.newRow.email) {
      alert('Employee Name and Email are required');
      return;
    }

    this.employeeService
      .createEmployee(this.newRow)
      .subscribe({

        next: () => {

          alert('Employee added successfully');

          this.isAddingNew = false;
          this.newRow = this.emptyEmployee();

          this.getEmployees();

        },

        error: (error) => {

          console.error('Create error:', error);

          alert(
            error.error?.message ||
            error.error ||
            'Failed to add employee'
          );

        }

      });

  }

  cancelAddEmployee(): void {

    this.isAddingNew = false;
    this.newRow = this.emptyEmployee();

  }


  // ==============================
  // INLINE EDIT EMPLOYEE
  // ==============================

  editEmployee(employee: any): void {

    this.editingId = employee.id;
    this.editRow = { ...employee };

  }

  saveEditEmployee(id: number): void {

    if (!this.editRow.employeeName || !this.editRow.email) {
      alert('Employee Name and Email are required');
      return;
    }

    this.employeeService
      .updateEmployee(id, this.editRow)
      .subscribe({

        next: () => {

          alert('Employee updated successfully');

          this.editingId = null;

          this.getEmployees();

        },

        error: (error) => {

          console.error('Update error:', error);

          alert(
            error.error?.message ||
            error.error ||
            'Failed to update employee'
          );

        }

      });

  }

  cancelEdit(): void {

    this.editingId = null;
    this.editRow = {};

  }


  // ==============================
  // DELETE EMPLOYEE
  // ==============================

  deleteEmployee(id: number): void {


    const confirmDelete =
      confirm(
        'Are you sure you want to delete this employee?'
      );


    if (!confirmDelete) {

      return;

    }


    this.employeeService
      .deleteEmployee(id)
      .subscribe({

        next: () => {

          alert(
            'Employee deleted successfully'
          );


          this.getEmployees();

        },


        error: (error) => {

          console.error(
            'Delete error:',
            error
          );


          alert(
            'Failed to delete employee'
          );

        }

      });

  }

}
