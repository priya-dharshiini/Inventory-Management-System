import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import { EmployeeService } from '../services/employee';
import { ProductService } from '../services/product';
import { AssetAssignmentService } from '../services/assetassignment';
import { MasterService } from '../services/master';

@Component({
  selector: 'app-asset-assignment',
  imports: [ReactiveFormsModule],
  templateUrl: './asset-assignment.html',
  styleUrl: './asset-assignment.css'
})
export class AssetAssignment implements OnInit {

  assignmentForm;

  employees: any[] = [];
  products: any[] = [];

  // Master-driven dropdown options
  departmentOptions: any[] = [];
  designationOptions: any[] = [];
  roleOptions: any[] = [];
  productStatusOptions: any[] = [];
  employeeStatusOptions: any[] = [];

  constructor(
    private fb: FormBuilder,
    private employeeService: EmployeeService,
    private productService: ProductService,
    private assetAssignmentService: AssetAssignmentService,
    private masterService: MasterService
  ) {

    this.assignmentForm = this.fb.group({

      employeeId: ['', Validators.required],

      productId: ['', Validators.required],

      assignmentType: ['PERMANENT', Validators.required],

      department: [''],

      designation: [''],

      role: [''],

      productStatus: [''],

      employeeStatus: [''],

      fromDate: ['', Validators.required],

      toDate: [''],

      remarks: ['']

    });
  }

  ngOnInit(): void {

    this.loadEmployees();

    this.loadProducts();

    this.loadMasterOptions();

  }


  // =========================
  // LOAD MASTER DROPDOWN OPTIONS
  // =========================

  loadMasterOptions(): void {

    this.masterService.getByType('DEPARTMENT').subscribe({
      next: (data) => { this.departmentOptions = data || []; },
      error: (error) => console.error('Error loading department master:', error)
    });

    this.masterService.getByType('DESIGNATION').subscribe({
      next: (data) => { this.designationOptions = data || []; },
      error: (error) => console.error('Error loading designation master:', error)
    });

    this.masterService.getByType('ROLE').subscribe({
      next: (data) => { this.roleOptions = data || []; },
      error: (error) => console.error('Error loading role master:', error)
    });

    // Product Status and Employee Status are fetched from two completely
    // separate master types, so their values can never mix.
    this.masterService.getByType('PRODUCT_STATUS').subscribe({
      next: (data) => { this.productStatusOptions = data || []; },
      error: (error) => console.error('Error loading product status master:', error)
    });

    this.masterService.getByType('EMPLOYEE_STATUS').subscribe({
      next: (data) => { this.employeeStatusOptions = data || []; },
      error: (error) => console.error('Error loading employee status master:', error)
    });

  }


  // =========================
  // WHEN EMPLOYEE CHANGES, PRE-FILL DEPARTMENT/DESIGNATION
  // =========================

  onEmployeeChange(): void {

    const employeeId = this.assignmentForm.value.employeeId;

    const selected = this.employees.find(
      (e) => String(e.id) === String(employeeId)
    );

    if (selected) {

      this.assignmentForm.patchValue({
        department: selected.department || '',
        designation: selected.designation || ''
      });

    }

  }


  // =========================
  // LOAD EMPLOYEES
  // =========================

  loadEmployees(): void {

    this.employeeService.getAllEmployees().subscribe({

      next: (data) => {

        console.log('Employees:', data);

        this.employees = data;

      },

      error: (error) => {

        console.error('Error loading employees:', error);

      }

    });
  }


  // =========================
  // LOAD PRODUCTS
  // =========================

  loadProducts(): void {

    this.productService.getAllProducts().subscribe({

      next: (data) => {

        console.log('Products:', data);

        this.products = data;

      },

      error: (error) => {

        console.error('Error loading products:', error);

      }

    });
  }


  // =========================
  // ASSIGNMENT TYPE CHANGE
  // =========================

  onAssignmentTypeChange(): void {

    const fromDate =
      this.assignmentForm.get('fromDate');

    const toDate =
      this.assignmentForm.get('toDate');


    if (
      this.assignmentForm.value.assignmentType ===
      'TEMPORARY'
    ) {

      fromDate?.setValidators([
        Validators.required
      ]);

      toDate?.setValidators([
        Validators.required
      ]);

    } else {

      fromDate?.setValidators([
        Validators.required
      ]);

      toDate?.clearValidators();

      toDate?.reset();

    }


    fromDate?.updateValueAndValidity();

    toDate?.updateValueAndValidity();

  }


  // =========================
  // SUBMIT ASSIGNMENT
  // =========================

  submitAssignment(): void {

    if (this.assignmentForm.invalid) {

      this.assignmentForm.markAllAsTouched();

      return;

    }


    const formValue =
      this.assignmentForm.value;


    console.log(
      'Assignment form:',
      formValue
    );


    this.assetAssignmentService
      .createAssignment(

        Number(formValue.employeeId),

        Number(formValue.productId),

        formValue.assignmentType!,

        formValue.fromDate!,

        formValue.toDate || '',

        formValue.remarks || '',

        formValue.department || '',

        formValue.designation || '',

        formValue.role || '',

        formValue.productStatus || '',

        formValue.employeeStatus || ''

      )
      .subscribe({

        next: (response) => {

          console.log(
            'Assignment created:',
            response
          );

          alert(
            'Asset assigned successfully!'
          );


          // Reset form

          this.assignmentForm.reset({

            employeeId: '',

            productId: '',

            assignmentType: 'PERMANENT',

            department: '',

            designation: '',

            role: '',

            productStatus: '',

            employeeStatus: '',

            fromDate: '',

            toDate: '',

            remarks: ''

          });


          // Reload products
          // Assigned product will disappear
          // because status becomes ASSIGNED

          this.loadProducts();

        },


        error: (error) => {

          console.error(
            'Assignment error:',
            error
          );


          alert(
            error.error?.message ||
            error.error ||
            'Failed to assign asset'
          );

        }

      });

  }


  // =========================
  // CANCEL
  // =========================

  cancelAssignment(): void {

    this.assignmentForm.reset({

      employeeId: '',

      productId: '',

      assignmentType: 'PERMANENT',

      department: '',

      designation: '',

      role: '',

      productStatus: '',

      employeeStatus: '',

      fromDate: '',

      toDate: '',

      remarks: ''

    });

  }

}