import { Router, RouterLink } from '@angular/router';

import { ProductService } from '../services/product';
import { MasterService } from '../services/master';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-product-management',
  imports: [
    RouterLink,
    FormsModule
  ],
  templateUrl: './product-management.html',
  styleUrl: './product-management.css'
})
export class ProductManagement implements OnInit {

  products: any[] = [];

  // =========================
  // MASTER DATA (for Status dropdown)
  // =========================

  statusOptions: any[] = [];

  // =========================
  // GOOGLE-STYLE PER-COLUMN SEARCH
  // =========================

  searchFields: any = {
    id: '',
    productName: '',
    productType: '',
    brand: '',
    model: '',
    serialNumber: '',
    status: '',
    purchaseDate: '',
    price: ''
  };

  private searchDebounce: any = null;

  // =========================
  // INLINE ADD
  // =========================

  isAddingNew: boolean = false;

  newRow: any = this.emptyProduct();

  // =========================
  // INLINE EDIT
  // =========================

  editingId: number | null = null;

  editRow: any = {};


  constructor(
    private productService: ProductService,
    private masterService: MasterService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}


  ngOnInit(): void {

    this.getProducts();
    this.loadStatusOptions();

  }


  emptyProduct(): any {
    return {
      productName: '',
      productType: '',
      brand: '',
      model: '',
      serialNumber: '',
      purchaseDate: '',
      price: null,
      status: 'AVAILABLE'
    };
  }


  // =========================
  // LOAD STATUS MASTER (for dropdown)
  // =========================

  loadStatusOptions(): void {

    // Product Status is fetched from the PRODUCT_STATUS master only —
    // never mixed with Employee Status values.
    this.masterService.getByType('PRODUCT_STATUS').subscribe({
      next: (data) => {
        this.statusOptions = data || [];
      },
      error: (error) => {
        console.error('Error loading status master:', error);
      }
    });

  }


  // =========================
  // GET PRODUCTS
  // =========================

  getProducts(): void {

    this.productService
      .getAllProducts()
      .subscribe({

        next: (data) => {

          this.products = [...data];

          this.cdr.detectChanges();

        },

        error: (error) => {

          console.error(
            'Error loading products:',
            error
          );

          alert('Failed to load products');

        }

      });

  }


  // =========================
  // GOOGLE-STYLE LIVE SEARCH (per field/column)
  // =========================

  onSearchInput(): void {

    if (this.searchDebounce) {
      clearTimeout(this.searchDebounce);
    }

    this.searchDebounce = setTimeout(() => {
      this.runSearch();
    }, 300);

  }

  runSearch(): void {

    const hasCriteria = Object.values(this.searchFields)
      .some((v: any) => v !== null && v !== undefined && String(v).trim() !== '');

    if (!hasCriteria) {
      this.getProducts();
      return;
    }

    this.productService
      .searchProducts(this.searchFields)
      .subscribe({

        next: (data) => {

          this.products = [...data];

          this.cdr.detectChanges();

        },

        error: (error) => {

          console.error('Search error:', error);

          this.products = [];

          this.cdr.detectChanges();

        }

      });

  }

  clearSearch(): void {

    this.searchFields = {
      id: '',
      productName: '',
      productType: '',
      brand: '',
      model: '',
      serialNumber: '',
      status: '',
      purchaseDate: '',
      price: ''
    };

    this.getProducts();

  }


  // =========================
  // INLINE ADD PRODUCT
  // =========================

  addProduct(): void {

    this.isAddingNew = true;
    this.newRow = this.emptyProduct();

  }

  saveNewProduct(): void {

    if (!this.newRow.productName || !this.newRow.serialNumber) {
      alert('Product Name and Serial Number are required');
      return;
    }

    this.productService
      .createProduct(this.newRow)
      .subscribe({

        next: () => {

          alert('Product added successfully');

          this.isAddingNew = false;
          this.newRow = this.emptyProduct();

          this.getProducts();

        },

        error: (error) => {

          console.error('Create error:', error);

          alert(
            error.error?.message ||
            error.error ||
            'Failed to add product'
          );

        }

      });

  }

  cancelAddProduct(): void {

    this.isAddingNew = false;
    this.newRow = this.emptyProduct();

  }


  // =========================
  // INLINE EDIT PRODUCT
  // =========================

  editProduct(product: any): void {

    this.editingId = product.id;
    this.editRow = { ...product };

  }

  saveEditProduct(id: number): void {

    if (!this.editRow.productName || !this.editRow.serialNumber) {
      alert('Product Name and Serial Number are required');
      return;
    }

    this.productService
      .updateProduct(id, this.editRow)
      .subscribe({

        next: () => {

          alert('Product updated successfully');

          this.editingId = null;

          this.getProducts();

        },

        error: (error) => {

          console.error('Update error:', error);

          alert(
            error.error?.message ||
            error.error ||
            'Failed to update product'
          );

        }

      });

  }

  cancelEdit(): void {

    this.editingId = null;
    this.editRow = {};

  }


  // =========================
  // DELETE PRODUCT
  // =========================

  deleteProduct(id: number): void {

    const confirmDelete = confirm(
      'Are you sure you want to delete this product?'
    );

    if (!confirmDelete) {

      return;

    }


    this.productService
      .deleteProduct(id)
      .subscribe({

        next: () => {

          alert(
            'Product deleted successfully'
          );

          this.getProducts();

        },

        error: (error) => {

          console.error(
            'Delete error:',
            error
          );

          alert(
            'Failed to delete product'
          );

        }

      });

  }

}
