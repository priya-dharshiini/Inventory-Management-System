import {
  Component,
  OnInit,
  ChangeDetectorRef
} from '@angular/core';

import { AssetAssignmentService } from '../services/assetassignment';

import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-assignment-register',

  imports: [
    FormsModule
  ],

  templateUrl: './assignment-register.html',

  styleUrl: './assignment-register.css'
})
export class AssignmentRegister implements OnInit {

  assignments: any[] = [];


  // =========================
  // SEARCH
  // =========================

  searchId: number | null = null;


  constructor(
    private assetAssignmentService: AssetAssignmentService,
    private cdr: ChangeDetectorRef
  ) {}


  ngOnInit(): void {

    this.getAssignments();

  }


  // =========================
  // LOAD ALL ASSIGNMENTS
  // =========================

  getAssignments(): void {

    this.assetAssignmentService
      .getAllAssignments()
      .subscribe({

        next: (data) => {

          console.log(
            'Assignments:',
            data
          );

          this.assignments = [...data];

          this.cdr.detectChanges();

        },

        error: (error) => {

          console.error(
            'Error loading assignments:',
            error
          );

          alert(
            'Failed to load assignments'
          );

        }

      });

  }


  // =========================
  // SEARCH ASSIGNMENT BY ID
  // =========================

  searchAssignment(): void {

    if (
      this.searchId === null ||
      this.searchId === undefined ||
      this.searchId <= 0
    ) {

      alert(
        'Please enter a valid Assignment ID'
      );

      return;

    }


    this.assetAssignmentService
      .getAssignmentById(this.searchId)
      .subscribe({

        next: (data) => {

          console.log(
            'Assignment Search Result:',
            data
          );


          // Search result-la
          // antha assignment mattum show aagum

          this.assignments = [data];


          this.cdr.detectChanges();

        },


        error: (error) => {

          console.error(
            'Assignment not found:',
            error
          );


          // Assignment kidaikala na
          // empty state show aagum

          this.assignments = [];

          this.cdr.detectChanges();


          alert(
            'Assignment not found'
          );

        }

      });

  }


  // =========================
  // CLEAR SEARCH
  // =========================

  clearSearch(): void {

    this.searchId = null;


    // Again all assignments load aagum

    this.getAssignments();

  }


  // =========================
  // RETURN ASSET
  // =========================

  returnAsset(id: number): void {

    const condition = prompt(
      'Enter asset condition (GOOD / DAMAGED):'
    );


    // User cancelled

    if (!condition) {

      return;

    }


    const remarks = prompt(
      'Enter return remarks:'
    ) || '';


    this.assetAssignmentService
      .returnAsset(
        id,
        condition,
        remarks
      )
      .subscribe({

        next: (response) => {

          console.log(
            'Asset returned:',
            response
          );


          alert(
            'Asset returned successfully!'
          );


          // Reload assignment list

          this.getAssignments();

        },


        error: (error) => {

          console.error(
            'Return asset error:',
            error
          );


          alert(
            error.error?.message ||
            error.error ||
            'Failed to return asset'
          );

        }

      });

  }

}